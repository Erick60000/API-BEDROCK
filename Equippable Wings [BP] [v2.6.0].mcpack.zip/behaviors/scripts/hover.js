import { system } from "lib/Util";
import { HOVER_SPEED, showParticles } from "./index";
import { playFlapSound } from "./sound";
import { reset } from "./reset";

export function isHovering(wings, player) {
    player.addEffect("slow_falling", 1, { showParticles });

    const vel = player.velocityV3(), cantFly = player.hasTag("player.isStarving") || player.cantFly;
    let yy = player.hoverY || 0, multipler = 1, amplifier = 1;

    if (player.isJumping && !cantFly) {
        if (!player.hasJumped && system.currentTick - player.jumpTick < 5) return reset(player).addTag('player.isFlying');
        delete player.hasSneaked;
        player.jumpTick = system.currentTick;
        player.hasJumped = true;
        delete player.hasSneaked;
        delete player.yy;

        yy = Math.min(yy + 0.02, 0.2);
        amplifier = 4;
    }
    else if (player.isSneaking || cantFly) {
        if (!player.hasSneaked && system.currentTick - player.sneakTick < 10) return reset(player).removeEffect("levitation");
        player.sneakTick = system.currentTick;
        player.hasSneaked = true;
        delete player.hasJumped;
        delete player.yy;

        yy = Math.max(yy - 0.01, -0.1);
    }
    else if (!player.isJumping && !player.isSneaking) {
        delete player.hasJumped;
        delete player.hasSneaked;
        yy *= 0.8;
        player.addEffect("levitation", 20, { showParticles });
    }

    if (!player.isSneaking) playFlapSound(player, wings);
    else delete player.lastFlapSound;

    if (player.isSprinting) {
        multipler *= 1.3;
        amplifier *= 2;
    }
    if (amplifier > 0) player.addEffect(`hunger`, 1, { amplifier, showParticles });

    let mag = Math.min(Math.sqrt(vel.x * vel.x + vel.z * vel.z), 0.2158 * multipler);
    if (mag < 0.01) mag = 0;
    const y_speed = mag * HOVER_SPEED * multipler;
    player.applyKnockback(vel.x, vel.z, y_speed, yy);
    player.hoverY = yy;
    if ((player.isOnGround && player.getVelocity().y == 0) || player.getBlock(0, 0.5, 0)?.isLiquid) return reset(player);
}

export default { isHovering };