import { system, Vector, map, world, MolangMap } from "lib/Util";
import { MAX_SPEED, MAX_FORCE, WINGS_SLOT, showParticles } from "./index";
import { playFlapSound } from "./sound";
import { reset } from "./reset";

export function isFlying(wings, player) {
    let amplifier = 0;
    player.addEffect("slow_falling", 20, { showParticles });
    
    if ((system.currentTick - player.lastPlayed) >= 20) {
        player.playSound(`wings.wind_effect${player.currentSoundIndex}`, { volume: 0.1 });
        player.lastPlayed = system.currentTick;
        player.currentSoundIndex = ++player.currentSoundIndex % 19;
    }

    let speed = MAX_SPEED + player.bonusSpeed;
    if (player.isSprinting) speed *= 1.2;

    const target = Vector.set(player.getViewDirection()).setMag(speed), vel = player.vel.limit(speed);
    if (player.hasTag("player.isStarving") || player.cantFly) target.y = Math.min(target.y, -0.1);
    const steering = Vector.sub(target, vel).limit(MAX_FORCE);
    const mag = Math.sqrt((vel.x ** 2) + (vel.z ** 2));
    let pitch = vel.y * 0.75;
    if (player.getRotation().x > 45) player.kamikazee += map(player.getRotation().x - 45, 0, 45, 0, 0.01);
    else player.kamikazee *= 0.95;

    if (vel.y > 0) amplifier = ~~(vel.y * (8 + (player.isSprinting ? 10 : 0))) + 1;
    else pitch = vel.y * 0.4;
    if (amplifier > 0) player.addEffect(`hunger`, 1, { amplifier, showParticles });

    player.applyKnockback(vel.x, vel.z, mag, pitch - player.kamikazee);
    if (player.isOnGround || player.getBlock(0, 0.5, 0)?.typeId === "minecraft:water") {
        if (player.isOnGround) kamikazee(player, player.kamikazee / 0.2);
        return reset(player);
    }
    if (player.isSneaking) return reset(player).addTag(`player.isHovering`);
    player.vel.add(steering);

    if (player.getRotation().x < -2) {
        playFlapSound(player, wings);
    } else delete player.lastFlapSound;
}

function kamikazee(player, level) {
    if (level < 1) return;
    let molang = new MolangMap().add("variable.shockwave_level", level);
    player.dimension.spawnParticle("ewings:shockwave_particle", player.v3().above(0.5), molang.getMap());

    let shakeLevel = [0.025, 0.05, 0.075][Math.floor(Math.min(level, 2))];
    let shakeTime = [0.25, 0.25, 0.25, 0.3, 0.35, 0.4, 0.5, 0.6][Math.min(Math.floor(level), 7)];
    player.runCommandAsync(`camerashake add @a[r=${Math.floor(level)}] ${shakeLevel} ${shakeTime}`);
    player.playSound("wings.ground_impact", { volume: 0.3 + Math.floor(level) });

    player.dimension.getEntities({ location: player.v3(), maxDistance: Math.floor(6 + level) }).some(e => {
        try {
            if (e.id === player.id) return;
            let n = Vector.sub(e.v3(), player.v3());
            let p = 1 - Math.min(Math.sqrt(n.x * n.x + n.z * n.z) / Math.floor(6 + level), 1);
            e.applyKnockback(n.x, n.z, p * Math.floor(level), 0.5);
            e.applyDamage(Math.floor(p * level), { damagingEntity: player, cause: "entityAttack" });
        } catch (er) { }
    });
}

export default { isFlying };