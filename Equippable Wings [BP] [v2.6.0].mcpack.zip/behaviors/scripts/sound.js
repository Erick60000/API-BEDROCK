import { system } from "lib/Util";

export function playFlapSound(player, wings) {
    let interval = 5;
    let delay = 5;
    let location = player.v3().add(0, 1, 0), volume = 0.3, pitch = 1;
    let sound = "wings.flap";
    if (wings.typeId === "ewings:fairy_15") return;
    else if (wings.typeId.includes("feather")) {
        interval = 8;
        delay = 12;
    }
    else if (wings.typeId.includes("dragonfly")) {
        sound = "dragonfly.flap";
        volume = 0.5;
        interval = 1;
        delay = 0;
    }
    else if (wings.typeId.includes("insect")) {
        sound = "dragonfly.flap";
        volume = 0.5;
        interval = 1;
        delay = 0;
    }
    else if (wings.typeId.includes("fairy")) {
        sound = "insect_wings.flap";
        volume = 0.5;
        interval = 5;
        delay = 0;
    }

    if (!player.lastFlapSound) player.lastFlapSound = system.currentTick;
    if ((system.currentTick - player.lastFlapSound) >= interval) {
        player.dimension.playSound(sound, location, { volume, pitch });
        player.lastFlapSound = system.currentTick + delay;
    }
}

export default { playFlapSound }