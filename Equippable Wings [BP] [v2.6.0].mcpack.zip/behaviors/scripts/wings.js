import { WINGS_SLOT } from "./index";
import { world } from "./lib/Util";

const lore_table = {
    "ewings:Mhafy1016": ["\n" + "by: ".dark_gray() + "Mhafy".green() + "1016".dark_green()]
}

export function updateWings(player) {
    try {
        player.findItem("ewings:").some(res => {
            let wings = res.item;
            //let wings = res.item, lore = [];
            //for (let i in lore_table) {
            //    if (wings.hasTag(i)) lore = (wings.getLore() || []).concat(lore_table[i]).unique();
            //}
            //wings.setLore(lore);
            if (wings.hasTag("ewings:wings_template")) return;
            if (!world.getDynamicProperty("ewings:theEnd")) {
                let wingsDurability = wings.durability();
                if (res.slot == WINGS_SLOT && (player.hasTag("player.isFlying") || player.hasTag("player.isHovering"))) {
                    let wingsDamage = Math.min(wingsDurability.damage + 1, wingsDurability.maxDurability);
                    wings.durability().damage = wingsDamage;
                    if (wingsDamage >= wingsDurability.maxDurability) player.cantFly = true;
                    else player.cantFly = false;
                }
                else {
                    let wingsDamage = Math.max(wingsDurability.damage - 1, 0);
                    wings.durability().damage = wingsDamage;
                }
                player.setItem(wings, res.slot);
            } else if (wings.durability().damage != 0) {
                wings.durability().damage = 0;
                player.setItem(wings, res.slot);
            }
        });
    } catch (err) { t}
}

export function getWingsType(wings) {
    let type = 0, skin = 0, scale = 1, color = { r: 255, g: 255, b: 255 };
    if (wings.typeId == "ewings:bat") {
        type = 0;
        skin = 0;
    }
    else if (wings.typeId.startsWith("ewings:demon")) {
        type = 1;
        skin = ["ewings:demon_0", "ewings:demon_1", "ewings:demon_2"].indexOf(wings.typeId);
    }
    else if (wings.typeId.startsWith("ewings:feather")) {
        type = 2;
        skin = 0;
    }
    else if (wings.typeId.startsWith("ewings:fairy")) {
        type = 3;
        skin = wings.typeId.split("_")[1];
        if (skin == 1) color = { r: 199, g: 78, b: 189 };
        else if (skin == 2) color = { r: 58, g: 179, b: 218 };
        else if (skin == 3) color = { r: 254, g: 216, b: 61 };
        else if (skin == 4) color = { r: 137, g: 50, b: 184 };
        else if (skin == 6) color = { r: 3, g: 173, b: 252 };
        else if (skin == 7) color = { r: 176, g: 46, b: 38 };
        else if (skin == 8) color = { r: 252, g: 3, b: 3 };
        else if (skin == 9) color = { r: 250, g: 107, b: 231 };
        else if (skin == 10) {
            color = { r: 128, g: 199, b: 31 };
            scale = 0.9;
        }
        else if (skin == 11) {
            color = { r: 58, g: 179, b: 218 };
            scale = 0.9;
        }
        else if (skin == 12) {
            color = { r: 249, g: 128, b: 29 };
            scale = 0.9;
        }
        else if (skin == 13) color = { r: 199, g: 78, b: 189 };
        else if (skin == 14) color = { r: 255, g: 145, b: 178 };
        else if (skin == 15) color = { r: 243, g: 226, b: 50 };
        else if (skin == 16) color = { r: 254, g: 216, b: 61 };
        else if (skin == 17) color = { r: 60, g: 68, b: 170 };
        else if (skin == 18) {
            color = { r: 137, g: 50, b: 184 };
            scale = 0.9;
        }
        else if (skin == 19) color = { r: 137, g: 50, b: 184 };
    }
    else if (wings.typeId.startsWith("ewings:insect")) {
        type = 4;
        skin = wings.typeId.split("_")[1];
    }
    color.r /= 255;
    color.g /= 255;
    color.b /= 255;
    return { type, skin, scale, color };
}

export default { updateWings, getWingsType };