import { world } from "lib/Util";

const table = {
    "minecraft:bat": {
        base: 0.1,
        explosion: 0.15,
        skeletons_arrow: 0.18,
        zombies_trident: 0.25,
        loot_table: "wings/bat"
    },
    "minecraft:vex": {
        base: 0.02,
        explosion: 0.07,
        skeletons_arrow: 0.10,
        zombies_trident: 0.20,
        loot_table: "wings/vex"
    },
    "minecraft:allay": {
        base: 0.4,
        explosion: 0.1,
        skeletons_arrow: 0.3,
        zombies_trident: 0.3,
        loot_table: "wings/allay"
    },
    "minecraft:bee": {
        base: 0.05,
        explosion: 0.10,
        skeletons_arrow: 0.13,
        zombies_trident: 0.20,
        loot_table: "wings/bee"
    },
    "minecraft:chicken": {
        base: 0.02,
        explosion: 0.07,
        skeletons_arrow: 0.10,
        zombies_trident: 0.20,
        loot_table: "wings/chicken"
    }
}

world.afterEvents.entityDie.subscribe(e => {
    try {
        let n = Math.random(), explosion = 0, arrow = 0, trident = 0, looting = 1;
        let id = `${e.deadEntity.typeId}`, attacker, cause = "";
        if (!world.getDynamicProperty("ewings:theEnd")) return;
        if (e.damageSource.damagingEntity) attacker = e.damageSource.damagingEntity;
        if (e.damageSource.cause) cause = e.damageSource.cause;
        if (!attacker?.typeId || !e.deadEntity?.typeId) return;
        if (attacker.typeId == "minecraft:creeper" && cause == "entityExplosion") explosion = 1;
        else if (attacker.typeId == "minecraft:skeleton" && cause == "projectile") arrow = 1;
        else if (attacker.typeId == "minecraft:zombie" && cause == "projectile") trident = 1;
        let item = attacker?.getEquipment("Mainhand");
        if (item) {
            let enchant = item.getComponent("minecraft:enchantable");
            if (enchant) looting += (enchant.getEnchantment("looting")?.level || 0);
        }
        if (table[id]) {
            let odds = table[id].base * looting;
            odds += table[id].explosion * explosion;
            odds += table[id].skeletons_arrow * arrow;
            odds += table[id].zombies_trident * trident;
            if (odds > n) return e.deadEntity.runCommandAsync(`loot spawn ~~~ loot "${table[id].loot_table}"`);
        }
        if (n < (0.05 * looting) + (0.10 * explosion) + (0.13 * arrow) + (0.20 * trident)) e.deadEntity.runCommandAsync(`summon ewings:demon_wings ~~~`);
    } catch (err) { console.warn(err); }
});

export default {};