import { world, system, ActionFormData, uiManager, MolangMap, Vector, RGB, OVERWORLD } from "lib/Util";
import { isFlying } from "./flight";
import { isHovering } from "./hover";
import { reset } from "./reset";
import { getWingsType, updateWings } from "./wings";
import { noise } from "./lib/noise";
import { } from "drops"

export const MAX_SPEED = 0.8;
export const MAX_FORCE = 0.15;
export const HOVER_SPEED = 1.2;
export const showParticles = false;
export const WINGS_SLOT = 17;
const VESION = "2.6.0";
const WINGS_FOLD_DURATION = 3; // in seconds

function load() {
    system.runInterval(tick, 0);
}

function screenRenderFinished(player) {
    player.firstLoadHUD = true;
    new ActionFormData().title("").button("Done").show(player).then(res => {
        if (res.cancelationReason == "UserBusy") return screenRenderFinished(player);
        player.sendMessage("===== " + "Equippable Wings".strong().aqua() + " =====");
        player.sendMessage("           * Fairy Core *");
        player.sendMessage("                [2.0.0]".gray() + "\n\n");
        player.sendMessage("by " + "Mhafy".strong().green() + "1016".strong().green() + "\n\n");
        player.firstInitializingUI = true;
    });
}

function tick() {
    for (let player of world.getPlayers()) {
        if (!player.isValid()) continue;
        if (player.scriptRetry >= 3) continue;
        try {
            if (player.vel == undefined) player.vel = player.vel = player.velocityV3();
            if (player.kamikazee == undefined) player.kamikazee = 0;
            if (player.bonusSpeed == undefined) player.bonusSpeed = 0;
            if (player.lastPlayed == undefined) player.lastPlayed = 0;
            if (player.currentSoundIndex == undefined) player.currentSoundIndex = 0;
            if (player.firstLoadHUD == undefined) screenRenderFinished(player);
            if (player.firstInitializingUI == undefined) uiManager.closeAllForms(player);
            if (player.isWingsFolded == undefined) player.isWingsFolded = 0;
            if (player.wingsFoldTimeout == undefined) player.wingsFoldTimeout = system.currentTick;
            if (player.sneakTimer == undefined) player.sneakTimer = 0;
            if (player.hasSneaked == undefined) player.hasSneaked = false;
            updateWings(player);

            if (player.hasTag("ewings:theEnd")) {
                player.sendMessage("= THE END =================\n* Wings trade increase\n* Mobs now drop Wings\n\n");
                world.setDynamicProperty("ewings:theEnd", true);
                player.removeTag("ewings:theEnd");
                delete player.cantFly;
            }
            if (player.hasTag("ewings:notTheEnd")) {
                world.setDynamicProperty("ewings:theEnd", false);
                player.removeTag("ewings:notTheEnd");
            }

            if (player.hasTag("player.isStarving")) {
                if (player.isStarving_tick > 0) player.isStarving_tick -= 1;
                else if (player.getHealth()?.currentValue > 1) {
                    player.removeTag(`player.isStarving`);
                    delete player.isStarving_tick;
                }
            }

            let wings = player.getItem(WINGS_SLOT);
            if (wings?.typeId.startsWith('ewings:')) {
                let flying = 0, hovering = 0, starving = (player.hasTag("player.isStarving") || player.cantFly) ? 1 : 0, color = ``;
                let wingsData = getWingsType(wings);
                if (player.hasTag('player.isFlying')) {
                    isFlying(wings, player);
                    player.isWingsFolded = 0;
                    flying = 1;
                }
                else if (player.hasTag('player.isHovering')) {
                    isHovering(wings, player);
                    player.isWingsFolded = 0;
                    hovering = 1;
                }
                else {
                    player.addEffect("slow_falling", 1, { showParticles });
                    if (player.isJumping) {
                        if (!player.hasJumped && system.currentTick - player.jumpTick < 5) {
                            player.addTag("player." + (player.isSneaking ? 'isHovering' : 'isFlying'));
                            delete player.jumpTick;
                            delete player.hasJumped;
                        }
                        player.jumpTick = system.currentTick;
                        player.hasJumped = true;
                    } else player.hasJumped = false;

                    if (player.isWingsFolded == 0) {
                        if (system.currentTick - player.wingsFoldTimeout >= (20 * WINGS_FOLD_DURATION)) player.isWingsFolded = 1;
                    }
                    if (!player.isSneaking && player.hasSneaked == true) {
                        player.sneakTimer = system.currentTick;
                        player.hasSneaked = false;
                    }
                    if (player.isSneaking) {
                        player.hasSneaked = true;
                        if (system.currentTick - player.sneakTimer <= 20) {
                            player.isWingsFolded = (player.isWingsFolded + 1) % 2;
                            if (player.isWingsFolded == 0) player.wingsFoldTimeout = system.currentTick + 140;
                            player.sneakTimer = 0;
                            player.hasSneaked = false;
                        }
                    }
                }
                color = wings.getDynamicProperty("ewings:color") || `v.wings_color_red=${wingsData.color.r};v.wings_color_green=${wingsData.color.g};v.wings_color_blue=${wingsData.color.b};`
                if (wingsData.type == 3 && wingsData.skin == 15) {
                    let effectColor = wings.getDynamicProperty("ewings:color_as_vector") || new Vector(wingsData.color.r, wingsData.color.g, wingsData.color.b);
                    player.dimension.spawnParticle("ewings:sparkle_particle", player.v3().above(0.95), new MolangMap().add("variable.color", new RGB(effectColor.x, effectColor.y, effectColor.z)).getMap());
                    const block = player.dimension.getBlock(player.v3().above());
                    if (block.typeId === "minecraft:air" || block.typeId === "ewings:ilaw") block.editState({ "ewings:timer": 1 }, "ewings:ilaw");

                    if (Math.random() < 0.2) {
                        let volume = 0.001 + Math.random() * 0.019;
                        let pitch = 0.7 + noise(system.currentTick * 0.5) * 1.3;
                        player.playSound("note.chime", { volume, pitch });
                    }
                }
                player.playAnimation("animation.wings.test", { stopExpression: `v.is_flying=${flying};v.is_hovering=${hovering};v.has_wings=1;v.wings_type=${wingsData.type};v.is_starving=${starving};v.wings_skin=${wingsData.skin};v.wings_scale=${wingsData.scale};v.is_folded=${player.isWingsFolded};${color}return !${system.currentTick};` });
            } else reset(player, 0);

            /**/
        } catch (err) {
            player.scriptRetry = (player.scriptRetry || 0) + 1
            uiManager.closeAllForms(player);
            reset(player);
            throw `${player.nameTag} has dealt an error\n ${3 - player.scriptRetry} tries left\n${err}`;
        }
    }
}

world.beforeEvents.worldInitialize.subscribe(e => {
    e.blockComponentRegistry.registerCustomComponent('ewings:light_block', {
        onTick: e => {
            if (e.block.typeId !== "ewings:ilaw") return;
            let timer = e.block.getState("ewings:timer");
            if (timer > 0) e.block.editState({ "ewings:timer": Math.max(timer - 1, 0) });
            else e.block.setType("minecraft:air");
        }
    });
});

world.afterEvents.playerInteractWithBlock.subscribe(e => {
    let { itemStack, player, block } = e;
    if (block?.typeId !== "minecraft:cauldron") return;
    let c = block.getComponent("minecraft:fluidContainer"), bool = false;
    if (!c) return;
    if (itemStack?.typeId.startsWith("ewings:feather")) bool = true;
    if (itemStack?.typeId.startsWith("ewings:fairy")) bool = true;
    if (itemStack?.typeId.startsWith("ewings:insect")) bool = true;
    if (!bool) return
    itemStack.setDynamicProperty("ewings:color", `v.wings_color_red=${c.fluidColor.red};v.wings_color_green=${c.fluidColor.green};v.wings_color_blue=${c.fluidColor.blue};`);
    itemStack.setDynamicProperty("ewings:color_as_vector", new Vector(c.fluidColor.red, c.fluidColor.green, c.fluidColor.blue).mult(1.05));
    player.setItem(itemStack);
});


world.afterEvents.playerSpawn.subscribe(e => { if (e.player.hasTag('player.isStarving')) e.player.isStarving_tick = 80; });
world.afterEvents.itemUse.subscribe(e => { if (e.itemStack?.typeId.startsWith("ewings:") && !e.itemStack?.hasTag("ewings:wings_template")) e.source.swapCurrentItem("", WINGS_SLOT); });
world.afterEvents.entityRemove.subscribe(e => OVERWORLD.runCommandAsync(`tag @a add "ewings:theEnd"`) , { entityTypes: ["minecraft:ender_dragon"] });

world.afterEvents.entityHurt.subscribe(e => {
    if (e.damageSource.cause !== "starve") return;
    e.hurtEntity.addTag("player.isStarving");
    e.hurtEntity.isStarving_tick = 80;
}, { entityTypes: ["minecraft:player"] });

world.afterEvents.entitySpawn.subscribe(e => {
    if (world.getDynamicProperty("ewings:theEnd")) {
        if (e.entity.typeId == "minecraft:wandering_trader" || (e.entity.typeId == "minecraft:villager_v2" && e.entity.hasFamily("armorer")))
            e.entity.triggerEvent("ewings:the_end_trades");
    }
});

world.afterEvents.itemCompleteUse.subscribe(e => {
    if (e.itemStack.getNutritionValue() < 0) return;
    e.source.removeTag(`player.isStarving`);
    if (e.source.getHealth()?.currentValue <= 1) e.source.getHealth().setCurrentValue(2);
});

world.afterEvents.dataDrivenEntityTrigger.subscribe(e => {
    if (!e.entity?.typeId === "minecraft:villager_v2" || !e.eventId?.includes("armorer")) return;
    if (world.getDynamicProperty("ewings:theEnd")) e.entity.triggerEvent("ewings:the_end_trades"); 
}, { entityTypes: ["minecraft:villager_v2"], eventTypes:[""] });

system.run(load);

export default { MAX_SPEED, MAX_FORCE, HOVER_SPEED, WINGS_SLOT, showParticles };