import { world, system, Vector } from "lib/Util";

export function reset(player, hasWings=1) {
    if (player.hasTag("player.isFlying") || player.hasTag("player.isHovering")) player.addEffect("slow_falling", 1, { amplifier: 10 });
    player.playAnimation("animation.wings.test", { stopExpression: `v.is_flying=0;v.is_hovering=0;v.has_wings=${hasWings};return !${system.currentTick};` });
    player.removeTag(`player.isFlying`);
    player.removeTag(`player.isHovering`);
    player.vel = new Vector(0, 0, 0);
    player.kamikazee = 0;
    player.currentSoundIndex = 0;
    player.wingsFoldTimeout = system.currentTick;
    delete player.hoverY;
    delete player.jumpTick;
    delete player.hasJumped;
    delete player.sneakTick;
    delete player.hasSneaked;
    delete player.lastFlapSound;
    player.removeEffect("levitation");

    return player;
}

export default { reset };